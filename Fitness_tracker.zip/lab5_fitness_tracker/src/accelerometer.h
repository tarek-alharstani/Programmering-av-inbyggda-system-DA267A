#include <driver/i2c.h>

#ifndef accelerometer_h
#define accelerometer_h

/*
 * Initialiserar accelerometern och I2C-kommunikationen.
 */
void init();

/*
 * Läser ett värde från accelerometern genom att kombinera de höga och låga registeradresserna.
 * regH: Adressen för det höga registret.
 * regL: Adressen för det låga registret.
 * Returnerar det lästa värdet som ett 16-bitars heltal.
 */
int16_t readAccelerometer(uint16_t regH, uint16_t regL);

/*
 * Beräknar och returnerar magnituden av accelerationen.
 * Returnerar ett 32-bitars heltal som representerar accelerationsmagnituden.
 */
u_int32_t getMagnitude();

#endif
