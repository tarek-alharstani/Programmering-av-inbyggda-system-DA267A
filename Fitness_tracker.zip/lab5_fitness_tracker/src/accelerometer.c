#include "accelerometer.h"
#include "math.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#define portTICK_RATE_MS (1000 / configTICK_RATE_HZ)


/*
 * Slave-adressen för MPU-60X0 är b110100X, vilket är 7 bitar långt.
 * LSB-biten av den 7-bitarsadressen bestäms av logiknivån på pin AD0.
 * Detta gör att två MPU-60X0-enheter kan kopplas till samma I2C-buss.
 * 
 * Om AD0 är låg, kommer I2C-adressen att vara 0x68. Annars kommer adressen att vara 0x69.
 */
#define MPU6050_ADDR 0x68

/*
 * Från databladet, sida 40:
 * Register (Hex): 6BSS
 * Bit7 DEVICE_RESET
 * Bit6 SLEEP
 * Bit5 CYCLE
 * Bit4 -
 * Bit3 TEMP_DIS
 * Bit2, Bit1, Bit0 CLKSEL[2:0]
 */
#define MPU6050_PWR_MGMT_1 0x6B

/*
 * Register (Hex) 19
 * Bit7, Bit6, Bit5, Bit4, Bit3, Bit2, Bit1, Bit0: SMPLRT_DIV[7:0]
 */
#define MPU6050_SMPLRT_DIV 0x19

/*
 * Från databladet, sida 45:
 * Register (Hex): 75
 * Bit7 -
 * Bit6, Bit5, Bit4, Bit3, Bit2, Bit1: WHO_AM_I[6:1]
 * Bit0: -
 */
#define MPU6050_WHO_AM_I 0x75

/*
 * Från databladet, sida 30:
 * Register (Hex) 41
 * Bit7 Bit6 Bit5 Bit4 Bit3 Bit2 Bit1 Bit0: TEMP_OUT[15:8]
 * Register (Hex) 42
 * Bit7 Bit6 Bit5 Bit4 Bit3 Bit2 Bit1 Bit0: TEMP_OUT[7:0]
 */
// #define MPU6050_TEMP_OUT_H 0x41
// #define MPU6050_TEMP_OUT_L 0x42

/*
 * Från databladet, sida 29:
 * Register (Hex) 3B | Bit 7-0: ACCEL_XOUT[15:8]
 * Register (Hex) 3C | Bit 7-0: ACCEL_XOUT[7:0]
 * Register (Hex) 3D | Bit 7-0: ACCEL_YOUT[15:8]
 * Register (Hex) 3E | Bit 7-0: ACCEL_YOUT[7:0]
 * Register (Hex) 3F | Bit 7-0: ACCEL_ZOUT[15:8]
 * Register (Hex) 40 | Bit 7-0: ACCEL_ZOUT[7:0]
 */
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_ACCEL_XOUT_L 0x3C
#define MPU6050_ACCEL_YOUT_H 0x3D
#define MPU6050_ACCEL_YOUT_L 0x3E
#define MPU6050_ACCEL_ZOUT_H 0x3F
#define MPU6050_ACCEL_ZOUT_L 0x40
//#define MPU6050_ACCEL_LSB 16384.f

i2c_cmd_handle_t cmd;
esp_err_t res;

void init () {
    /* 
     * Konfigurera och installera drivrutin
     */ 
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,                    // ESP32 agerar som master
        .sda_io_num = 33,                           // pin för SDA
        .sda_pullup_en = GPIO_PULLUP_ENABLE,        // SDA och SCL-linjerna är aktiva låga, så de ska dras upp med motstånd
        .scl_io_num = 32,                           // SCL pin nummer
        .scl_pullup_en = GPIO_PULLUP_ENABLE,        // aktiverar pull-up på SDA
        .master.clk_speed = 100000,                 // Standardläge (100 Kbit/s)
    };

    /*
     * Konfigurera I2C-kontroller 0
     */ 
    esp_err_t res = i2c_param_config(I2C_NUM_0, &conf);
    ESP_ERROR_CHECK(res);

    /* 
     * Installera drivrutinen, inga buffertar behövs i masterläge eller speciell interrupt-konfiguration
     */
    res = i2c_driver_install(I2C_NUM_0, conf.mode, 0, 0, 0);
    ESP_ERROR_CHECK(res);

    /* 
     * Konfigurera strömläge
     * Här sätter vi alla bitar i PWR_MGMT_1-registret till 0
     * Skapa kommando
     */
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();

    // starta kommando
    res = i2c_master_start(cmd);                
    ESP_ERROR_CHECK(res);

    // sätt adress + skriv och kolla efter ack
    res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_WRITE, 1);
    ESP_ERROR_CHECK(res);                       

    // skriv registeradressen och kolla efter ack
    res = i2c_master_write_byte(cmd, MPU6050_PWR_MGMT_1, 1);
    ESP_ERROR_CHECK(res);

    // skriv värde för registret: 0, och kolla efter ack
    res = i2c_master_write_byte(cmd, 0x00, 1);
    ESP_ERROR_CHECK(res);

    // slut på kommando
    res = i2c_master_stop(cmd);
    ESP_ERROR_CHECK(res);

    // skicka kommando, 1 sekund timeout
    res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
    ESP_ERROR_CHECK(res);

    // ta bort kommando nu när det inte behövs
    i2c_cmd_link_delete(cmd);


    /** 
     * Läser len bytes och placerar dem i en buffert, bufferten måste vara förallokerad
     * 
     * Ställ in samplingsfrekvensen
     * Samplingsfrekvensen är gyro samplingsfrekvens / (1 + divider)
     * Genom att sätta divider till 250 får vi en samplingsfrekvens på 32 Hz
     */
    cmd = i2c_cmd_link_create();
    res = i2c_master_start(cmd);
    ESP_ERROR_CHECK(res);

    res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_WRITE, 1); // Sätt WRITE bit!
    ESP_ERROR_CHECK(res);

    res = i2c_master_write_byte(cmd, MPU6050_SMPLRT_DIV, 1); // skriv till SMPLRT_DIV
    ESP_ERROR_CHECK(res);

    res = i2c_master_write_byte(cmd, 250, 1); // sätt SMPLRT_DIV till 250
    ESP_ERROR_CHECK(res);

    res = i2c_master_stop(cmd);
    ESP_ERROR_CHECK(res);

    res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
    // ESP_ERROR_CHECK(res);

    i2c_cmd_link_delete(cmd);

}

u_int32_t getMagnitude() {
    double ACCEL_X = readAccelerometer(MPU6050_ACCEL_XOUT_H, MPU6050_ACCEL_XOUT_L);
    double ACCEL_Y = readAccelerometer(MPU6050_ACCEL_YOUT_H, MPU6050_ACCEL_YOUT_L);
    double ACCEL_Z = readAccelerometer(MPU6050_ACCEL_ZOUT_H, MPU6050_ACCEL_ZOUT_L);

    //Bas 2 på grund av det binära talsystemet
    u_int32_t returnVal = sqrt(pow(ACCEL_X, 2) + pow(ACCEL_Y, 2) + pow(ACCEL_Z, 2));

    return returnVal;
}

int16_t readAccelerometer(uint16_t regH, uint16_t regL) {
        /*
         * Läs den senaste uppmätta accelerationen
         * Vi behöver kombinera TEMP_OUT_L och TEMP_OUT_H till ett 16-bitars signerat heltal
         * och sedan konvertera det till C med formeln: t = temp_out /340 + 36.53
         * Skapa en liten buffert för att lagra svaret
         */
        uint8_t buffer;             
        int16_t accRaw = 0;

        /*
         * Läs låg register
         * Läs bara registernummer utan annan data
         */
        cmd = i2c_cmd_link_create();
        res = i2c_master_start(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_WRITE, 1); // Sätt WRITE bit!
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, regL, 1); // läs låg först
        ESP_ERROR_CHECK(res);

        res = i2c_master_stop(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
        ESP_ERROR_CHECK(res);

        i2c_cmd_link_delete(cmd);

        // vänta lite
        vTaskDelay(10 / portTICK_RATE_MS);

        // nu läs svaret
        cmd = i2c_cmd_link_create();
        res = i2c_master_start(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_READ, 1); // Sätt READ bit!
        ESP_ERROR_CHECK(res);

        res = i2c_master_read(cmd, &buffer, 1, I2C_MASTER_NACK);
        ESP_ERROR_CHECK(res);

        res = i2c_master_stop(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
        ESP_ERROR_CHECK(res);

        i2c_cmd_link_delete(cmd);

        accRaw = buffer;    

        /* 
         * Läs hög register
         */ 
        cmd = i2c_cmd_link_create();
        res = i2c_master_start(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_WRITE, 1); // Sätt WRITE bit!
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, regH, 1); // läs hög
        ESP_ERROR_CHECK(res);

        res = i2c_master_stop(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
        ESP_ERROR_CHECK(res);

        i2c_cmd_link_delete(cmd);
        vTaskDelay(10 / portTICK_RATE_MS);

        cmd = i2c_cmd_link_create();
        res = i2c_master_start(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_write_byte(cmd, MPU6050_ADDR << 1 | I2C_MASTER_READ, 1); // Sätt READ bit!
        ESP_ERROR_CHECK(res);

        res = i2c_master_read(cmd, &buffer, 1, I2C_MASTER_NACK);
        ESP_ERROR_CHECK(res);

        res = i2c_master_stop(cmd);
        ESP_ERROR_CHECK(res);

        res = i2c_master_cmd_begin(I2C_NUM_0, cmd, 1000 / portTICK_RATE_MS);
        ESP_ERROR_CHECK(res);

        i2c_cmd_link_delete(cmd);

        /* 
         * Kombinera hög och låg register till ett signerat heltal
         */
        accRaw |= ((int16_t)buffer) << 8;
        //printf("Acc raw is: %d\n", accRaw);

        return accRaw;

        /*
         * Konvertera råvärde till temperatur
         */
        // float temp = ((float)tempRaw) / 340 + 36.53;
        // printf("Temperaturen är: %.2f C\n", temp);
        // vTaskDelay(500 / portTICK_RATE_MS);
}
