#include "accelerometer.h"
#include "circular_buffer.h"
#include "math.h"
#include "stdio.h"
#include <esp_pm.h>
#include <esp_task_wdt.h>
#include <esp_log.h>
#include <math.h>
#include <string.h>
#include <stdio.h> 
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <driver/gpio.h>
#include <esp_sleep.h>
#include <esp_system.h>
#include <driver/i2c.h>
#include <esp_event.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>


// """@ Tarek And Fadi "


/////////////  DEFINITIONER /////////////
/**
 * Anledningen till att jag har valt denna samplingsfrekvens är att
 * jag uppskattar 180 steg/min = 3 steg/s. 
 * 100 bör täcka allt. 
 */ 
#define SAMPLING_PERIOD 100   

/**
 * Anledningen till att jag har valt denna buffertstorlek är att
 * data lagras var 100ms och töms var 3000ms vilket betyder 
 * 30, men jag ökade den till 50 för att vara säker på att täcka allt.
 */ 
#define BUFF_SIZE 50

/**
 * Jag har valt att köra algoritmen var 3000ms 
 * för att säkerställa att täcka några perioder. 
 * Jag har testat detta värde fram och tillbaka, men 10 perioder fungerar bra. 
 */ 
#define ALGO_PERIOD 3000

/**
 * Minsta SD för att undvika att konvergera till 0
 */ 
#define MIN_SD 500

/*
 * Konstant applicerad på SD för att upptäcka steg
 * Bör vara någonstans mellan 1-3. 
 * Jag testade 1.1 
 * JAG HAR EN FRÅGA! VARFÖR STRÄCKER DET SIG UPP TILL 3?? 
 */ 
#define K 1.1

/**
 * Minsta tid mellan steg, detta värde är valt för att
 * jag förväntar mig en fördröjning på ca 300ms för steg (3 steg/s)
 */ 
#define MIN_INTRA_STEP_TIME 300

/**
 * Dagsmål för steg
 */ 
#define STEPS_GOAL 10

#define LED_PIN 26
#define BUTTON_PIN 14 
//#define SCL_PIN 32
//#define SDA_PIN 33
///////////////////////////////////////

/////////////  INITIALISERINGAR /////////////
SemaphoreHandle_t xSemaphore = NULL;
struct circularBuffer buffer;
int step_count = 0;
///////////////////////////////////////

/////////////  SAMPLING TASK /////////////
static void sampling_task(void *arg) {

  TickType_t xLastWakeTime = xTaskGetTickCount();

  while (1) {
     /**
      * Hämta accelerationen
      * Beräkna magnituden - görs i accelerometern
      * Placera magnituden i bufferten
      * Skriv ut innehållet av magnituden - för mycket text
      */ 
        u_int32_t acc = getMagnitude();
        addElement(&buffer, acc);
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(SAMPLING_PERIOD));
    } 
}
///////////////////////////////////////

/////////////  KNAPPTRYCKT /////////////
void button_handler(void *arg) {
    // Ge semaphore (observera: detta är i en ISR!)
    xSemaphoreGiveFromISR(xSemaphore, NULL);
}
///////////////////////////////////////

/////////////  ALGORITM TASK /////////////
static void algo_task(void *arg) {

    TickType_t xLastWakeTime = xTaskGetTickCount();
    
        while (1) {
            
            // Hämta storleken på bufferten
            u_int32_t size = getsize(&buffer);
            // Hämta svansen för loopar
            u_int32_t tail = buffer.tail;
        
            if (size > 0) {
                /**
                 * Beräkna medelvärde, här töms inte kön när den läses! 
                 * Får genomsnittet av bufferdata.
                 */ 
                double mean = 0;

                for (int i = buffer.head; i != tail; i = modulus_inc(buffer.maxLength, i)) {
                    mean += buffer.data[i];
                }
                
                mean = (mean / (double)size);


                /**
                 * Beräkna SD, här måste kön inte tömmas ännu
                 * Får standardavvikelsen av bufferdata 
                 * genom att subtrahera genomsnittet, i pow. 
                 * pow() = beräkna kraften (data-genomsnitt) upphöjt till basvärdet (2). 
                 */
                double sd = 0;
                
                for (int i = buffer.head; i != tail; i = modulus_inc(buffer.maxLength, i)) {
                    sd += pow((buffer.data[i] - mean), 2);
                }

                //sqrt() = returnerar argumentets kvadratrot 
                sd = sqrt((sd / (double)size));
                if (sd < MIN_SD) sd = MIN_SD;

                /*
                 * Nu gör vi stegräkning, samtidigt som vi tömmer kön
                 */
                u_int32_t sample;
                u_int32_t lastStepTS = -MIN_INTRA_STEP_TIME;
                
                for (int i = 0; i < size; i++) {
                    // Hämta sample, ta bort det från kön
                    sample = removeHead(&buffer);

                    // Om sample > medelvärde + K * sd
                    if (sample > mean + K * sd) {

                        // OCH om tiden mellan sista steget och detta sample är > MIN_INTRA_STEP_TIME
                        // Vi vill kolla efter ökning i acceleration
                        if (i * SAMPLING_PERIOD - lastStepTS > MIN_INTRA_STEP_TIME) {
                                    // Steg hittat! step_count++;
                                    step_count++;
                                    lastStepTS = i * SAMPLING_PERIOD;
                        }
                    }
                }
            }
            printf("Steg: %d\n", step_count);
            vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(ALGO_PERIOD));
        }
}
///////////////////////////////////////

/////////////  LED /////////////
void led_task(void *arg) {
    while (1) {
      
        if (xSemaphoreTake(xSemaphore, portMAX_DELAY) == pdTRUE) {
            // Blinka LED med sekvens beroende på om step_count > STEPS_GOAL
            if (step_count >= STEPS_GOAL) {
                gpio_set_level(LED_PIN, 1);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 1);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(200));               
                gpio_set_level(LED_PIN, 1);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 1);
                vTaskDelay(pdMS_TO_TICKS(200));
                gpio_set_level(LED_PIN, 0);
            }
        }
    }
}

void app_main() {
    /*
     * LIGHT SLEEP-konfiguration
     * Konfigurera lätt sömnläge med esp_pm_configure()
     * 
     * Från espressif webbplats: 
     * Drivrutin för en perifer enhet klockad från APB kan begära att APB-frekvensen 
     * sätts till 80 MHz medan periferin används.
     */
    esp_pm_config_esp32_t light_sleep_config = {
        .max_freq_mhz = 80,
        .min_freq_mhz = 15,  
        .light_sleep_enable = 1,
    };
    esp_err_t errr = esp_pm_configure(&light_sleep_config);
  
    xSemaphore = xSemaphoreCreateBinary();
    
    xTaskCreate(led_task, "led_task", 2048, NULL, 10, NULL);


    gpio_set_direction(BUTTON_PIN, GPIO_MODE_INPUT);

    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);

    // Ställ in knappen med intern pullup
    gpio_set_pull_mode(BUTTON_PIN, GPIO_PULLUP_ONLY);

    // Aktivera interrupt på fallande (1->0) kant för knapp-pinnen
    gpio_set_intr_type(BUTTON_PIN, GPIO_INTR_NEGEDGE);

    // Installera ISR-tjänst med standardkonfiguration
    gpio_install_isr_service(0);

    // Fäst interrupt-service-rutinen
    gpio_isr_handler_add(BUTTON_PIN, button_handler, NULL);

    // Initialisera bufferten
    u_int32_t *data = (uint32_t *)malloc(BUFF_SIZE * sizeof(uint32_t));
    initCircularBuffer(&buffer, data, BUFF_SIZE);

    // Initialisera I2C-bussen och MPU6050
    init();

    /**
     * Skapa sampling task
     * Prioritet 0 = idle task 
     * Högsta prioritet anges i FreeRTOSConfig.h 
     * OBS! Uppgiftens prioritet ≄ Interrupt-prioritet! 
    */
    xTaskCreate(sampling_task, "sampling", 2048, NULL, 1, NULL);
    xTaskCreate(algo_task, "algo", 2048, NULL, 0, NULL);
}
 
