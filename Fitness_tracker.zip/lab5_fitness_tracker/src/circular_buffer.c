#include <stdio.h>
#include <limits.h>
#include "circular_buffer.h"

/*
 * Initialiserar en tom cirkulär buffert.
 */
void initCircularBuffer(struct circularBuffer* bufferPtr, u_int32_t* data, int maxLength) {
    
    bufferPtr->data = data;             // Tilldela pekaren för data
    bufferPtr->head = 0;                 // Sätt huvudet till 0 (början av bufferten)
    bufferPtr->tail = 0;                 // Sätt svansen till 0 (början av bufferten)
    bufferPtr->maxLength = maxLength;   // Sätt maxlängd på bufferten

    // Tillagd: Initialisera storleken på bufferten till 0
    bufferPtr->size = 0; 
}

/*
 * Lägger till ett värde i bufferten vid svansen.
 * Returnerar INT_MIN om bufferten är full, annars returneras värdet som lades till.
 */
u_int32_t addElement(struct circularBuffer* bufferPtr, u_int32_t value) {

    // Kollar om bufferten är full (om nästa svansposition är samma som huvudet)
    if (modulus_inc(bufferPtr->maxLength, bufferPtr->tail) == bufferPtr->head) {
        return INT_MIN;   // Bufferten är full, returnera INT_MIN
    } 
    
    else {
        // Lägg till värdet i bufferten
        bufferPtr->data[bufferPtr->tail] = value;
        bufferPtr->tail = modulus_inc(bufferPtr->maxLength, bufferPtr->tail);  // Uppdatera svansen
        
        bufferPtr->size++;  // Öka storleken på bufferten
        return value;  // Returera det tillagda värdet
    }
}

/*
 * Tar bort det äldsta elementet från bufferten (från huvudet).
 * Returnerar INT_MIN om bufferten är tom, annars returneras det borttagna värdet.
 */
u_int32_t removeHead(struct circularBuffer* bufferPtr) {
    
    // Kollar om bufferten är tom
    if (bufferPtr->head == bufferPtr->tail) {
        return INT_MIN;   // Bufferten är tom, returnera INT_MIN
    } 
    
    else {
        u_int32_t temp = bufferPtr->data[bufferPtr->head];  // Spara det borttagna värdet
        bufferPtr->head = modulus_inc(bufferPtr->maxLength, bufferPtr->head);  // Uppdatera huvudet
        bufferPtr->size--;  // Minska storleken på bufferten
        return temp;  // Returnera det borttagna värdet
    }
}

/*
 * Returnerar antalet element i bufferten.
 */
u_int32_t getsize(struct circularBuffer* bufferPtr) { 
    return bufferPtr->size;  // Returnera storleken på bufferten
}

/*
 * Hjälpfunktion för att öka ett värde med modulus, används för att hålla koll på svansen och huvudet i en cirkulär buffert.
 */
int modulus_inc(int maxLength, int val) { 
    return (val + 1) % maxLength;  // Öka och använd modulus för att hålla sig inom buffertens gränser
}

/*
 * Hjälpfunktion för att minska ett värde, används för att hålla koll på buffertens index.
 */
int decrement(int maxLength, int val) {
    if (val == 0) {
        return maxLength - 1;  // Om värdet är 0, sätt det till buffertens sista index
    } 
    else {
        return val - 1;  // Annars minska värdet
    }
}
