#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H


/* 
 * Datastruktur som används för att hålla en cirkulär buffert.
 */
struct circularBuffer{
  u_int32_t * data;
  int head;
  int tail;
  int maxLength;
  u_int32_t size;
};

int modulus_inc(int maxLength, int val);

int decrement(int maxLength, int val); 

/*
 * Initialisera en tom buffert.
 */
void initCircularBuffer(struct circularBuffer* bufferPtr, uint32_t* data, int maxLen);

/*
 * Denna funktion ska lägga till värdet som anges av argumentet 'value' 
 * vid slutet av bufferten.
 *
 * Funktionen ska returnera:
 *  - 'value' om värdet framgångsrikt lades till i kön.
 *  - INT_MIN (definierad i limits.h) om värdet inte lades till.
 */
u_int32_t addElement(struct circularBuffer* bufferPtr, u_int32_t value);


/* 
 * Ta bort det äldsta elementet, vilket är vid huvudet av kön. 
 * 
 * Funktionen ska returnera:
 *   - 'value' om huvudelementet framgångsrikt togs bort
 *   - INT_MIN (definierad i limits.h) om inget element togs bort (dvs. kön var tom när funktionen anropades).       
 */
u_int32_t removeHead(struct circularBuffer* bufferPtr);


u_int32_t getsize(struct circularBuffer* bufferPtr);


#endif
